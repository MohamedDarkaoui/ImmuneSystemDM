This directory contains the training data for 17 different epitopes
